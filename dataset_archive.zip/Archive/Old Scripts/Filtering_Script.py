# smart_folder_filtering_cic_iot2023.py
# Author: Yashwant Salunkhe

import pandas as pd
import os

# Step 1: Set the folder path where all merged CSVs are stored
folder_path = "C:/Users/yashw/OneDrive/Desktop/AI-ML/MERGED_CSV"  # <-- Update this path to your folder

# Step 2: List all CSV files in the folder
csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]

print(f"\nFound {len(csv_files)} CSV files in folder.")

# Step 3: Process each file one by one
for file_name in csv_files:
    file_path = os.path.join(folder_path, file_name)
    print(f"\n🔍 Processing file: {file_name}...")

    try:
        df = pd.read_csv(file_path)

        if 'Label' not in df.columns:
            print(" Skipped: No 'Label' column found.")
            continue

        attack_labels = df['Label'].unique()
        ransomware_found = any('ransomware' in label.lower() for label in attack_labels)

        if ransomware_found:
            print(" Ransomware samples found!")

            # Filtering
            df_ransomware = df[df['Label'].str.contains('Ransomware', case=False, na=False)]
            df_benign = df[df['Label'].str.contains('Benign', case=False, na=False)]

            if df_ransomware.empty:
                print(" No Ransomware rows found after filtering, skipping.")
                continue

            # Assign labels
            df_ransomware['Attack_Label'] = 1
            df_benign['Attack_Label'] = 0

            # Merge datasets
            final_df = pd.concat([df_ransomware, df_benign])

            print(f"Final filtered dataset shape: {final_df.shape}")

            # Save filtered dataset
            output_file = f"filtered_{file_name}"
            output_path = os.path.join(folder_path, output_file)
            final_df.to_csv(output_path, index=False)

            print(f" Saved: {output_file}")

        else:
            print(" No Ransomware attacks in this file. Skipping.")

    except Exception as e:
        print(f" Error processing {file_name}: {str(e)}")

print("\n🏁 All files processed!")
