# train_ransomware_detection_models.py
# Author: Yashwant Salunkhe

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

# Step 1: Load the cleaned dataset
dataset_path = "C:\Users\yashw\OneDrive\Desktop\AI-ML\final_backdoor_ransomware_clean.csv"  # Update this path if needed
print(f"Loading dataset from: {dataset_path}")
df = pd.read_csv(dataset_path)

print("\n Dataset Loaded!")
print("Shape:", df.shape)
print(df.head())

# Step 2: Split features and labels
X = df.drop(['Attack_Label'], axis=1)
y = df['Attack_Label']

# Step 3: Train/Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

# Step 4: Train RandomForest
print("\n Training RandomForest...")
rf_model = RandomForestClassifier(n_estimators=150, random_state=42)
rf_model.fit(X_train, y_train)

# Step 5: Train LightGBM
print("\n Training LightGBM...")
lgb_model = LGBMClassifier(n_estimators=300, learning_rate=0.05, max_depth=10, random_state=42)
lgb_model.fit(X_train, y_train)

# Step 6: Train XGBoost
print("\n Training XGBoost...")
xgb_model = XGBClassifier(n_estimators=250, learning_rate=0.05, max_depth=8, use_label_encoder=False, eval_metric='logloss', random_state=42)
xgb_model.fit(X_train, y_train)

# Step 7: Build Voting Classifier
print("\n Training Voting Classifier (Ensemble)...")
voting_model = VotingClassifier(
    estimators=[
        ('rf', rf_model),
        ('lgb', lgb_model),
        ('xgb', xgb_model)
    ],
    voting='soft'
)
voting_model.fit(X_train, y_train)

# Step 8: Evaluate Models
models = {
    "Random Forest": rf_model,
    "LightGBM": lgb_model,
    "XGBoost": xgb_model,
    "Voting Ensemble": voting_model
}

for name, model in models.items():
    print(f"\n Evaluation Report for {name}:")
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred))
    print(f"{name} Accuracy Score: {accuracy_score(y_test, y_pred):.4f}")

    # Confusion Matrix
    plt.figure(figsize=(5,4))
    sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap="Blues")
    plt.title(f"{name} - Confusion Matrix")
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.show()
