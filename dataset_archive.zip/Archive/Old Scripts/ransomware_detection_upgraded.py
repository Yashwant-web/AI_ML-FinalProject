# ransomware_detection_upgraded.py
# Project: Improving Early Detection of Ransomware in IoT Devices
# Author: Yashwant Salunkhe

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import requests
import base64
import time

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE
from lightgbm import LGBMClassifier

# Step 1: Load the realistic dataset
print("Loading the realistic ransomware IoT dataset...")
dataset_path = "C:/Users/yashw/OneDrive/Desktop/AI-ML/realistic_ransomware_iot_dataset.csv"  # Update if needed
df = pd.read_csv(dataset_path)

print("Dataset shape:", df.shape)
print("First few rows of the dataset:")
print(df.head())

# Step 2: Preprocessing
df = df.dropna()

X = df.drop('Label', axis=1)
y = df['Label']

# Step 3: Train/Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42)

# Step 4: Apply SMOTE to balance training data
print("\nApplying SMOTE...")
sm = SMOTE(random_state=42)
X_train, y_train = sm.fit_resample(X_train, y_train)

# Step 5: Tune Random Forest using GridSearchCV
print("\nTuning Random Forest...")
rf = RandomForestClassifier(random_state=42)
param_grid = {
    'n_estimators': [150, 300],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 4],
    'min_samples_leaf': [1, 2]
}
grid_search_rf = GridSearchCV(estimator=rf, param_grid=param_grid, scoring='f1', cv=5, verbose=1, n_jobs=-1)
grid_search_rf.fit(X_train, y_train)
best_rf = grid_search_rf.best_estimator_

# Step 6: Train LightGBM with better parameters
print("\nTraining LightGBM...")
lgb_model = LGBMClassifier(
    boosting_type='gbdt',
    learning_rate=0.05,
    n_estimators=500,
    max_depth=10,
    num_leaves=31,
    random_state=42
)
lgb_model.fit(X_train, y_train)

# Step 7: Train XGBoost
print("\nTraining XGBoost...")
xgb_model = XGBClassifier(
    learning_rate=0.05,
    n_estimators=300,
    max_depth=8,
    use_label_encoder=False,
    eval_metric='logloss',
    random_state=42
)
xgb_model.fit(X_train, y_train)

# Step 8: Create Voting Classifier (Ensemble)
print("\nTraining Voting Classifier Ensemble...")
ensemble_model = VotingClassifier(estimators=[
    ('rf', best_rf),
    ('xgb', xgb_model),
    ('lgb', lgb_model)
], voting='soft')  # 'soft' uses probabilities

ensemble_model.fit(X_train, y_train)

# Step 9: Evaluate all models
models = {
    'Optimized Random Forest': best_rf,
    'LightGBM': lgb_model,
    'XGBoost': xgb_model,
    'Voting Ensemble': ensemble_model
}

for name, model in models.items():
    print(f"\nEvaluation Report for {name}:")
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred))
    print(f"{name} Accuracy Score: {accuracy_score(y_test, y_pred):.4f}")

    # Plot confusion matrix
    plt.figure(figsize=(6,5))
    sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap="Blues")
    plt.title(f"{name} - Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.show()

# Step 10: VirusTotal Threat Intelligence API (Optional Scan)
def check_virustotal_url(url_to_check, api_key):
    """Function to scan URL using VirusTotal API and print scan results."""
    headers = {"x-apikey": api_key}
    
    scan_url = "https://www.virustotal.com/api/v3/urls"
    params = {'url': url_to_check}
    response = requests.post(scan_url, headers=headers, data=params)
    
    if response.status_code != 200:
        print("Error submitting URL to VirusTotal:", response.text)
        return None

    url_bytes = url_to_check.encode()
    url_base64 = base64.urlsafe_b64encode(url_bytes).decode().strip("=")

    report_url = f"https://www.virustotal.com/api/v3/urls/{url_base64}"

    print("Waiting 15 seconds for VirusTotal to scan...")
    time.sleep(15)

    response = requests.get(report_url, headers=headers)
    if response.status_code != 200:
        print("Error retrieving report from VirusTotal:", response.text)
        return None

    result = response.json()
    stats = result['data']['attributes']['last_analysis_stats']
    
    print("\nVirusTotal Scan Results for URL:", url_to_check)
    print("Malicious:", stats['malicious'])
    print("Harmless:", stats['harmless'])
    print("Suspicious:", stats['suspicious'])
    print("Undetected:", stats['undetected'])
    
    return stats

# Uncomment to use VirusTotal
your_api_key = "88612485f39f59b28a71228762121299fd2c72c7c749018f6b7023469a226a69"  # Replace with your actual API key
sample_url = "http://testphp.vulnweb.com"
check_virustotal_url(sample_url, your_api_key)
