# Ransomware Detection Project - Final Code
# Author: Yashwant Salunkhe
# Project: Improving Early Detection of Ransomware in IoT Devices

# Description: This code implements a machine learning pipeline for detecting ransomware in IoT devices using Random Forest and XGBoost classifiers.
# It also integrates with the VirusTotal API for threat intelligence.  
# The dataset used is 'CICIDS 2023 - CICIOT2023 Big Dataset' from the Canadian Institute for Cybersecurity.
# The dataset is available at: https://www.unb.ca/cic/datasets/malmem-2023.html
# The code includes data preprocessing, model training, evaluation, and visualization of results.
# The code also includes a function to check URLs against the VirusTotal API for malicious content.
# Import necessary libraries
# Note: Ensure you have the required libraries installed. You can install them using pip if needed.
# pip install pandas numpy matplotlib seaborn scikit-learn xgboost requests



import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import requests
import base64
import time

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from xgboost import XGBClassifier
from imblearn.over_sampling import SMOTE
from lightgbm import LGBMClassifier

# Step 1: Load the improved dataset
print("Loading the better dataset...")
dataset_path = "C:/Users/yashw/OneDrive/Desktop/AI-ML/cleaned_ransomware_iot_dataset.csv"  # update if needed
df = pd.read_csv(dataset_path)

print("Dataset shape:", df.shape)
print("First few rows:")
print(df.head())

# Step 2: Preprocessing
df = df.dropna()

# Separating features and labels
X = df.drop('Label', axis=1)
y = df['Label']

# Splitting into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42)

# Step 3: Handling imbalance with SMOTE
print("\nApplying SMOTE to balance the classes...")
sm = SMOTE(random_state=42)
X_train, y_train = sm.fit_resample(X_train, y_train)

# Step 4: Hyperparameter Tuning for Random Forest
print("\nTuning Random Forest with GridSearchCV...")
param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [10, 20, None],
    'min_samples_split': [2, 5],
    'min_samples_leaf': [1, 2]
}

rf = RandomForestClassifier(random_state=42)
grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, scoring='f1', cv=5, verbose=1, n_jobs=-1)
grid_search.fit(X_train, y_train)

best_rf = grid_search.best_estimator_

# Predictions and Evaluation - Random Forest
y_pred_rf = best_rf.predict(X_test)
print("\nOptimized Random Forest Evaluation Report:")
print(classification_report(y_test, y_pred_rf))
print("Optimized Random Forest Accuracy:", accuracy_score(y_test, y_pred_rf))

# Plotting confusion matrix
plt.figure(figsize=(6,5))
sns.heatmap(confusion_matrix(y_test, y_pred_rf), annot=True, fmt='d', cmap="Blues")
plt.title("Random Forest - Confusion Matrix")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.show()

# Step 5: Training LightGBM Classifier
print("\nTraining LightGBM Classifier...")
lgb_model = LGBMClassifier(random_state=42)
lgb_model.fit(X_train, y_train)

y_pred_lgb = lgb_model.predict(X_test)

# Evaluation for LightGBM
print("\nLightGBM Evaluation Report:")
print(classification_report(y_test, y_pred_lgb))
print("LightGBM Accuracy Score:", accuracy_score(y_test, y_pred_lgb))

# Plotting confusion matrix for LightGBM
plt.figure(figsize=(6,5))
sns.heatmap(confusion_matrix(y_test, y_pred_lgb), annot=True, fmt='d', cmap="Greens")
plt.title("LightGBM - Confusion Matrix")
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.show()

# Step 6: VirusTotal Integration (optional usage)
def check_virustotal_url(url_to_check, api_key):
    """Function to scan URL with VirusTotal API and print the results."""
    headers = {"x-apikey": api_key}
    
    # Submitting URL for scanning
    scan_url = "https://www.virustotal.com/api/v3/urls"
    params = {'url': url_to_check}
    response = requests.post(scan_url, headers=headers, data=params)
    
    if response.status_code != 200:
        print("Error submitting URL to VirusTotal:", response.text)
        return None

    # Encoding the URL properly
    url_bytes = url_to_check.encode()
    url_base64 = base64.urlsafe_b64encode(url_bytes).decode().strip("=")

    report_url = f"https://www.virustotal.com/api/v3/urls/{url_base64}"

    # Wait to allow VirusTotal to process
    print("Waiting 15 seconds before retrieving the report...")
    time.sleep(15)

    # Fetching the report
    response = requests.get(report_url, headers=headers)
    if response.status_code != 200:
        print("Error retrieving report from VirusTotal:", response.text)
        return None

    result = response.json()
    stats = result['data']['attributes']['last_analysis_stats']
    
    print("\nVirusTotal Scan Results for URL:", url_to_check)
    print("Malicious:", stats['malicious'])
    print("Harmless:", stats['harmless'])
    print("Suspicious:", stats['suspicious'])
    print("Undetected:", stats['undetected'])
    
    return stats

# Example for VirusTotal (uncomment to use)
your_api_key = "88612485f39f59b28a71228762121299fd2c72c7c749018f6b7023469a226a69"  # Replace with your actual API key
sample_url = "http://testphp.vulnweb.com"
check_virustotal_url(sample_url, your_api_key)
